package net.codejava.SpringBootThymeform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeformApplicationTests {

	@Test
	void contextLoads() {
	}

}
